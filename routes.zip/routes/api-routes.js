/* eslint-disable no-use-before-define */
/* eslint-disable consistent-return */
const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const db = require('../models');
const verifyToken = require('../middleware/verifyToken');

// Promisify bcrypt.comp
function bcryptComp(plain, hash) {
  return new Promise((res, rej) => {
    bcrypt.compare(plain, hash, (err, result) => {
      result ? res(true) : res(false);
    });
  });
}
// Promisify jwt.verify
function jwtVerify(token, secret) {
  return new Promise((res, rej) => {
    jwt.verify(token, secret, (err, authData) => {
      if (err) {
        rej(err);
      } else {
        res(authData);
      }
    });
  });
}

// bcryptComp('1234679', '$2b$10$my5pe3OfdX18xW0Tr7hZXuF5R/2nIhbIZsJ3FsML11cKYfH.W/BsO').then((res) => console.log(res)).catch((err) => console.log(false));

const router = express.Router();

const secret = 'Groupxyz';
/// use router instead of app when creating the routes
// start the api routees without'/api/' , i.e. router.get('/user/') instead of app.get('/api/user')
router.post('/createuser', verifyToken, async (req, res) => {
  const authData = await jwtVerify(req.token, secret);
  console.log(authData);
  // Give the new user a default password of 123456789 and hash it before adding into the database
  if (authData.level === 100) {
    bcrypt.hash('123456789', 10, (err, hash) => {
      db.User.create({
        first_name: req.body.f_name,
        last_name: req.body.l_name,
        mobile: req.body.mob,
        office_number: req.body.off,
        email: req.body.email,
        password: hash,
        RoleId: req.body.rolid,
      }).then((data) => {
        res.sendStatus(200).json(data);
      });
    });
  } else {
    res.sendStatus(403).json({ msg: 'Sorry you are not allowed to add new users' });
  }
});

router.post('/createdept', (req, res) => {
  db.Dept.create({ name: req.body.name }).then(() => res.sendStatus(200));
});

router.post('/createrole', (req, res) => {
  db.Role.create({
    title: req.body.title,
    hourly_rate: req.body.wage,
    management_level: req.body.level,
    DeptId: req.body.deptid,

  }).then((data) => res.sendStatus(200).json(data)).catch((err) => res.sendStatus(404).json({ msg: 'Failed to create new role' }));
});

db.User.findOne({
  where: {
    email: 'tony@abc.com',
   }, 
  include: [db.Role],
  
}).then((user) => {
console.log(user);
});



router.post('/login', (req, res) => {
  db.User.findOne({
    where: {
      email: req.body.email,
     }, 
    //  include: [db.Role],
    
  }).then((user) => {
    console.log(user.dataValues);
    if (user) {
      bcryptComp(req.body.password, user.dataValues.password).then((result) => {
        console.log(result);
        if (result) {
          jwt.sign({ user: user.email }, secret, { expiresIn: '15m' }, (err, token) => {
            res.json({ token });
          });
        } else {
          res.sendStatus(403);
        }
      });
    }
  }).catch((err) => {
    throw err;
  });
});
//
router.post('/adduser', verifyToken, (req, res) => {
  jwt.verify(req.token, secret, (err, authData) => {
    if (err) {
      throw err;
    } else {
      res.json({
        msg: 'Your data has been added',
        authData,
      });
    }
  });
});

module.exports = router;
